const airportData = [
  { code: "DEL", name: "Indira Gandhi International Airport", city: "Delhi", country: "India" },
  { code: "JFK", name: "John F. Kennedy International Airport", city: "New York", country: "USA" },
  { code: "LHR", name: "London Heathrow Airport", city: "London", country: "UK" },
  { code: "DXB", name: "Dubai International Airport", city: "Dubai", country: "UAE" },
  { code: "HND", name: "Tokyo Haneda Airport", city: "Tokyo", country: "Japan" }
];

export default airportData;

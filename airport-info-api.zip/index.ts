import express from "express";
import airportData from './airportData';
import { AppDataSource } from './data-source';

const app = express();
const PORT = 3000;

app.get("/", (req, res) => {
  res.send("Hello from Airport Info API!");
});

app.get("/api/airport-info", (req, res) => {
  const code = req.query.code as string;

  if (!code) {
    return res.status(400).json({ error: "Airport code is required." });
  }

  const airport = airportData.find((a) => a.code === code.toUpperCase());

  if (!airport) {
    return res.status(404).json({ error: "Airport not found." });
  }

  res.json(airport);
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
